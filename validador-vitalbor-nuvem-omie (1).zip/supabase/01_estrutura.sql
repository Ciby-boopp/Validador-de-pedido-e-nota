-- =====================================================================
--  Validador de Nota · Vitalbor — estrutura no Supabase
--  Como usar: Supabase › SQL Editor › New query › cole tudo › Run.
--  Pode rodar de novo sem perder dados (só cria o que falta).
--  ANTES DE RODAR: troque o e-mail na última parte (primeiro gestor).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Quem pode entrar e com qual perfil
--    gestor ....... tudo, inclusive liberar usuários
--    faturamento .. confere e fatura na Omie
--    comercial .... confere, cotações e cadastros
--    leitura ...... só vê
-- ---------------------------------------------------------------------
create table if not exists public.usuarios (
  email      text primary key check (email = lower(email)),
  nome       text,
  papel      text not null default 'leitura' check (papel in ('gestor','faturamento','comercial','leitura')),
  ativo      boolean not null default true,
  criado_em  timestamptz not null default now(),
  criado_por text
);

-- Perfil de quem está logado (vazio = sem acesso). Usado por todas as regras abaixo.
-- Só vale login feito pelo Google: uma conta de e-mail e senha criada com o e-mail
-- de outra pessoa não ganha acesso, mesmo que o cadastro de e-mail esteja ligado.
create or replace function public.papel_atual() returns text
language sql stable security definer set search_path = public as $$
  select u.papel from public.usuarios u
   where u.email = lower(coalesce(auth.jwt() ->> 'email', ''))
     and u.ativo
     and coalesce(auth.jwt() -> 'app_metadata' -> 'providers', '[]'::jsonb) ? 'google'
     and exists (select 1 from jsonb_array_elements(
                   case when jsonb_typeof(auth.jwt() -> 'amr') = 'array' then auth.jwt() -> 'amr' else '[]'::jsonb end) a
                 where coalesce(a ->> 'method', a #>> '{}') = 'oauth')
$$;
revoke all on function public.papel_atual() from public, anon;
grant execute on function public.papel_atual() to authenticated;

alter table public.usuarios enable row level security;
drop policy if exists usuarios_ler on public.usuarios;
drop policy if exists usuarios_incluir on public.usuarios;
drop policy if exists usuarios_alterar on public.usuarios;
drop policy if exists usuarios_excluir on public.usuarios;
create policy usuarios_ler on public.usuarios for select to authenticated
  using (email = lower(auth.jwt() ->> 'email') or public.papel_atual() = 'gestor');
create policy usuarios_incluir on public.usuarios for insert to authenticated
  with check (public.papel_atual() = 'gestor');
create policy usuarios_alterar on public.usuarios for update to authenticated
  using (public.papel_atual() = 'gestor') with check (public.papel_atual() = 'gestor');
create policy usuarios_excluir on public.usuarios for delete to authenticated
  using (public.papel_atual() = 'gestor');

-- ---------------------------------------------------------------------
-- 2) Cadastros e configurações (produtos, preços, transportadoras, caixas,
--    regras fiscais...). Mesmo formato que o validador usava no navegador.
--    "versao" impede que uma pessoa apague sem querer a alteração da outra.
-- ---------------------------------------------------------------------
create table if not exists public.dados (
  chave          text primary key,
  valor          jsonb,
  versao         integer not null default 1,
  atualizado_em  timestamptz not null default now(),
  atualizado_por text
);
alter table public.dados enable row level security;
drop policy if exists dados_ler on public.dados;
drop policy if exists dados_incluir on public.dados;
drop policy if exists dados_alterar on public.dados;
create policy dados_ler on public.dados for select to authenticated
  using (public.papel_atual() is not null);
create policy dados_incluir on public.dados for insert to authenticated
  with check (public.papel_atual() in ('gestor','faturamento','comercial'));
create policy dados_alterar on public.dados for update to authenticated
  using (public.papel_atual() in ('gestor','faturamento','comercial'))
  with check (public.papel_atual() in ('gestor','faturamento','comercial'));

-- Grava só se ninguém salvou antes (devolve a nova versão; vazio = conflito)
create or replace function public.dados_salvar(p_chave text, p_valor jsonb, p_versao integer)
returns integer language plpgsql security invoker set search_path = public as $$
declare v integer;
begin
  if coalesce(p_versao, 0) = 0 then
    insert into public.dados (chave, valor, versao, atualizado_por)
    values (p_chave, p_valor, 1, auth.jwt() ->> 'email')
    on conflict (chave) do nothing
    returning versao into v;
  else
    update public.dados
       set valor = p_valor, versao = versao + 1, atualizado_em = now(), atualizado_por = auth.jwt() ->> 'email'
     where chave = p_chave and versao = p_versao
    returning versao into v;
  end if;
  return v;
end $$;
revoke all on function public.dados_salvar(text, jsonb, integer) from public, anon;
grant execute on function public.dados_salvar(text, jsonb, integer) to authenticated;

-- ---------------------------------------------------------------------
-- 3) Histórico das conferências (uma linha por análise)
--    "liberada" = conferida e liberada para faturar.
--    faturado_em / faturado_por / omie_resposta: só a função do servidor grava,
--    depois que a Omie confirma o faturamento.
-- ---------------------------------------------------------------------
create table if not exists public.historico (
  id                 bigint generated always as identity primary key,
  criado_em          timestamptz not null default now(),
  atualizado_em      timestamptz not null default now(),
  dia                date not null default ((now() at time zone 'America/Sao_Paulo')::date),
  criado_por         text default (auth.jwt() ->> 'email'),
  pedido text, nota text, cliente text, uf text, transp text, valor text,
  ok                 boolean not null default false,
  liberada           boolean not null default false,
  pend               jsonb not null default '[]'::jsonb,
  omie_codigo_pedido bigint,
  omie_snapshot      jsonb,          -- o pedido da Omie exatamente como estava na conferência
  faturado_em        timestamptz,
  faturado_por       text,
  omie_resposta      jsonb,
  constraint liberada_so_se_ok check (not liberada or ok)
);
create index if not exists historico_dia_idx on public.historico (dia desc);

create or replace function public.historico_tocar() returns trigger language plpgsql as $$
begin new.atualizado_em := now(); return new; end $$;
drop trigger if exists historico_tocar on public.historico;
create trigger historico_tocar before update on public.historico for each row execute function public.historico_tocar();

alter table public.historico enable row level security;
drop policy if exists hist_ler on public.historico;
drop policy if exists hist_incluir on public.historico;
drop policy if exists hist_alterar on public.historico;
drop policy if exists hist_excluir on public.historico;
create policy hist_ler on public.historico for select to authenticated
  using (public.papel_atual() is not null);
create policy hist_incluir on public.historico for insert to authenticated
  with check (public.papel_atual() in ('gestor','faturamento','comercial')
              and faturado_em is null and faturado_por is null and omie_resposta is null);
create policy hist_alterar on public.historico for update to authenticated
  using (public.papel_atual() in ('gestor','faturamento','comercial') and faturado_em is null)
  with check (faturado_em is null and faturado_por is null and omie_resposta is null);
create policy hist_excluir on public.historico for delete to authenticated
  using (public.papel_atual() = 'gestor' and faturado_em is null);

-- ---------------------------------------------------------------------
-- 4) Cotações
-- ---------------------------------------------------------------------
create table if not exists public.cotacoes (
  id         bigint generated always as identity primary key,
  numero     text not null unique,
  criado_em  timestamptz not null default now(),
  criado_por text default (auth.jwt() ->> 'email'),
  dados      jsonb not null
);
alter table public.cotacoes enable row level security;
drop policy if exists cot_ler on public.cotacoes;
drop policy if exists cot_incluir on public.cotacoes;
drop policy if exists cot_excluir on public.cotacoes;
create policy cot_ler on public.cotacoes for select to authenticated
  using (public.papel_atual() is not null);
create policy cot_incluir on public.cotacoes for insert to authenticated
  with check (public.papel_atual() in ('gestor','faturamento','comercial'));
create policy cot_excluir on public.cotacoes for delete to authenticated
  using (public.papel_atual() = 'gestor'
         or (public.papel_atual() in ('faturamento','comercial') and criado_por = auth.jwt() ->> 'email'));

-- ---------------------------------------------------------------------
-- 5) Registro de tudo que o sistema manda gravar na Omie (auditoria).
--    Só a função do servidor grava. Só o gestor lê.
-- ---------------------------------------------------------------------
create table if not exists public.omie_log (
  id         bigint generated always as identity primary key,
  em         timestamptz not null default now(),
  email      text, papel text, endpoint text, chamada text,
  parametros jsonb, ok boolean, resposta jsonb
);
alter table public.omie_log enable row level security;
drop policy if exists log_ler on public.omie_log;
create policy log_ler on public.omie_log for select to authenticated
  using (public.papel_atual() = 'gestor');

-- ---------------------------------------------------------------------
-- 6) Uso interno da função do servidor (sem acesso pelo navegador):
--    trava = a Omie não aceita duas gravações ao mesmo tempo
--    cache = a Omie recusa a mesma consulta repetida em menos de 60 s
-- ---------------------------------------------------------------------
create table if not exists public.omie_trava (
  id  integer primary key default 1 check (id = 1),
  ate timestamptz not null default now()
);
insert into public.omie_trava (id) values (1) on conflict (id) do nothing;
alter table public.omie_trava enable row level security;

create table if not exists public.omie_cache (
  chave    text primary key,
  resposta jsonb,
  em       timestamptz not null default now()
);
alter table public.omie_cache enable row level security;

-- Quem não está logado não acessa nada
revoke all on public.usuarios, public.dados, public.historico, public.cotacoes,
              public.omie_log, public.omie_trava, public.omie_cache from anon;
revoke all on public.omie_trava, public.omie_cache from authenticated;

-- ---------------------------------------------------------------------
-- 7) PRIMEIRO GESTOR — troque pelo e-mail Google com que você vai entrar
-- ---------------------------------------------------------------------
insert into public.usuarios (email, nome, papel)
values (lower('SEU-EMAIL@gmail.com'), 'Seu nome', 'gestor')
on conflict (email) do update set papel = 'gestor', ativo = true;
